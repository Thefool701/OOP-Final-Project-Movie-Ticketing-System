package proj2;

import javax.swing.*;
import java.awt.*;

//code for coming soon and now showing(images & description)
public class movieSelection {

        public static void main(String[] args) {
            // Create the main frame 
            JFrame frame = new JFrame("Movie Selection");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 800);
            frame.setLayout(new BorderLayout(10, 10));

            // CardLayout to switch (Now Showing and Coming Soon)
            JPanel contentPanel = new JPanel(new CardLayout());
            frame.add(contentPanel, BorderLayout.CENTER);

            // panel for the buttons at the top
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());

            // "Now Showing" button
            JButton nowShowingButton = new JButton("NOW SHOWING");
            nowShowingButton.setFont(new Font("Arial", Font.BOLD, 20)); 
            buttonPanel.add(nowShowingButton);
            nowShowingButton.setBackground(new Color(199, 185, 198));
            

            // "Coming Soon" button
            JButton comingSoonButton = new JButton("COMING SOON");
            comingSoonButton.setFont(new Font("Arial", Font.BOLD, 20)); 
            buttonPanel.add(comingSoonButton);
            comingSoonButton.setBackground(new Color(199, 185, 198));
            frame.add(buttonPanel, BorderLayout.NORTH);

            // Create "Now Showing" panel
            JPanel nowShowingPanel = createMoviePanel(
                new String[]{"resources/moana.jpg", "resources/wicked2.jpg", "resources/gladiator.jpg", "resources/helloloveagain.jpg"},
                new String[]{"MOANA 2", "WICKED", "GLADIATOR II", "HELLO, LOVE, AGAIN"},
                new String[]{
                    "After receiving an unexpected call from her wayfinding ancestors, Moana must journey to the far seas of Oceania and into dangerous, long-lost waters for an adventure unlike anything she’s ever faced.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 1 hours 40 minutes.",
                    "After two decades as one of the most beloved and enduring musicals on the stage, Wicked makes its long-awaited journey to the big screen as a spectacular, generation-defining two-part cinematic event this holiday season.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 2 hours 40 minutes.",
                    "From legendary director Ridley Scott, Gladiator II continues the epic saga of power, intrigue, and vengeance set in Ancient Rome. Years after witnessing the death of the revered hero Maximus at the hands of his uncle, Lucius is forced to enter the Colosseum after his home is conquered by the tyrannical Emperors who now lead Rome with an iron fist. With rage in his heart and the future of the Empire at stake, Lucius must look to his past to find strength and honor to return the glory of Rome to its people.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 2 hours 27 minutes.",
                    "After 5 years apart, Joy and Ethan say their hellos once more. As they rediscover each other, they navigate the complexities of their new lives in Canada, finding romance and connection amidst changes.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 2 hours 02 minutes."
                }
            );

                // Create Coming Soon  panel
                JPanel comingSoonPanel = createMoviePanel(
                    new String[]{"resources/greenbones.jpg", "resources/werewolves.jpg", "resources/breadwinner.jpg", "resources/lionking.jpg"},
                    new String[]{"GREEN BONES", "WEREWOLVES", "THE BREAD WINNER IS", "MUFASA: THE LION KING"},
                    new String[]{
                        "It is believed that green bones found in a person’s cremated remains are proof of a person’s goodness in life. Remorseless criminals could never hold such a bone in their body… A man notorious for the grisly murder of his sister and niece will soon be released from prison. But a newly assigned corrections officer takes a personal interest in making sure that the murderer remains behind bars no matter what it takes.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 1 hours 40 minutes.",
                        "Racing against a rising supermoon turning millions into killer werewolves, a former marine and biophysicist (Frank Grillo) must fight to find a cure and save his family.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 1 hours 33 minutes.",
                        "This comedy film is about a mistaken identity which leads to a promising opportunity when designated breadwinner, Bambi Salvador, played by Vice Ganda, heads home to her own funeral. Turns out, Bambi was robbed by a thief who eventually got into a horrific accident, face crushed but with all of Bambi’s belongings – leaving the authorities and her family to presume it was her. With a 10 million insurance claim under her name on the line, Bambi may finally reclaim their home that was mortgaged due to piles of debt. Bambi, together with her dysfunctional family, decides to keep the ridiculous act of her death in order to claim money that will solve all their problems. Now, Bambi has 40 days to play dead to keep her family alive – with or without her.\r\n" + //
                                        "\r\n" + 
                                        "Run Time: 2 hours 03 minutes.",
                        "Roaring to cinemas this December, “Mufasa: The Lion King” enlists Rafiki to relay the legend of Mufasa to young lion cub Kiara, daughter of Simba and Nala, with Timon and Pumbaa lending their signature schtick. Told in flashbacks, the story introduces Mufasa as an orphaned cub, lost and alone until he meets a sympathetic lion named Taka—the heir to a royal bloodline. The chance meeting sets in motion an expansive journey of an extraordinary group of misfits searching for their destiny—their bonds will be tested as they work together to evade a threatening and deadly foe. Come celebrate the arrival of the king in cinemas this December 18.\r\n" + //
                                        "\r\n" + //
                                        "Run Time: 1 hours 57 minutes."
                    });

                // Add panels to contentPanel
                contentPanel.add(nowShowingPanel, "nowShowing");
                contentPanel.add(comingSoonPanel, "comingSoon");

                // Show  Now Showing  by default
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "nowShowing");

                // Add action listeners to buttons
                nowShowingButton.addActionListener(e -> {
                    if (e.getSource() == nowShowingButton) {
                    cl.show(contentPanel, "nowShowing");
                }
                });

                comingSoonButton.addActionListener(e -> {
                    if (e.getSource() == comingSoonButton) {
                    cl.show(contentPanel, "comingSoon");
                    }
                });

            // frame visibility
            frame.setVisible(true);
        }

        // make posters clickable
        @SuppressWarnings("unused")
        private static JPanel createMoviePanel(String[] posterPaths, String[] movieTitles, String[] descriptions) {
        JPanel moviePanel = new JPanel(new GridLayout(2, 2, 10, 10)); 
        moviePanel.setBackground(Color.LIGHT_GRAY); 
    
            for (int i = 0; i < posterPaths.length; i++) {
                String posterPath = posterPaths[i];
                String movieTitle = movieTitles[i];
                String description = descriptions[i];
    
                // Create a panel to hold the poster and the button
                JPanel movieContainer = new JPanel();
                movieContainer.setLayout(new BorderLayout(5, 5));
                movieContainer.setBackground(Color.WHITE);

                // Set preferred size to match poster size + padding
                movieContainer.setPreferredSize(new Dimension(200, 370)); 

                //border matching the poster size
                movieContainer.setBorder(BorderFactory.createLineBorder(Color.GRAY, 3)); 
    
                //poster label
                JLabel posterLabel = new JLabel(resizeImageIcon(posterPath, 250, 320));
                posterLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

                // Add mouse listener for zoom effect
                posterLabel.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        // Zoom in 
                        posterLabel.setIcon(resizeImageIcon(posterPath, 260, 320));
                    }
    
                    @Override
                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        // Revert to original size
                        posterLabel.setIcon(resizeImageIcon(posterPath, 250, 300));
                    }
                });
                
                
                // Add title label below the poster
                JLabel titleLabel = new JLabel(movieTitle, SwingConstants.CENTER);
                titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
                titleLabel.setForeground(Color.DARK_GRAY);
                titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

                // Create "View Movie Details" button
                JButton viewDetailsButton = new JButton("View Movie Details");
                viewDetailsButton.setFont(new Font("Arial", Font.BOLD, 14));
            
    
                // Add an action listener to the button
                viewDetailsButton.addActionListener(e -> showMovieDetails(movieTitle, description, posterPath));
    
                // Create a panel to hold the title label and button
                JPanel bottomPanel = new JPanel(new BorderLayout(5, 5)); 
                bottomPanel.setBackground(Color.WHITE);
                bottomPanel.add(titleLabel, BorderLayout.NORTH); 
                bottomPanel.add(viewDetailsButton, BorderLayout.SOUTH); 

                // Add components to the movieContainer panel
                movieContainer.add(posterLabel, BorderLayout.CENTER);
                movieContainer.add(bottomPanel, BorderLayout.SOUTH);

                // Add movie container to the main movie panel (grid)
                moviePanel.add(movieContainer);
            }

         return moviePanel;
        }
    
            // Method to display movie details on a new screen
            private static void showMovieDetails(String movieTitle, String description, String posterPath) {
                JFrame detailsFrame = new JFrame(movieTitle);
                    detailsFrame.setSize(600, 700);
                    detailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                    JPanel panel = new JPanel(new BorderLayout(10, 10));

                    // Create and style the title label
                    JLabel titleLabel = new JLabel(movieTitle, SwingConstants.CENTER);
                    titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
                    titleLabel.setForeground(Color.BLACK);
                    titleLabel.setOpaque(true); 
                    titleLabel.setBackground(new Color(199, 185, 198)); 
                    panel.add(titleLabel, BorderLayout.NORTH);

                    // Add poster label to display image
                    JLabel posterLabel = new JLabel(resizeImageIcon(posterPath, 400, 500), SwingConstants.CENTER);
                    panel.add(posterLabel, BorderLayout.CENTER);

                    // Display the movie description in a scrollable text area
                    JTextArea descriptionArea = new JTextArea(description);
                    descriptionArea.setEditable(false);
                    descriptionArea.setWrapStyleWord(true);
                    descriptionArea.setLineWrap(true);
                    descriptionArea.setFont(new Font("Arial", Font.PLAIN, 16));
                    panel.add(new JScrollPane(descriptionArea), BorderLayout.SOUTH);

                    // Add the panel to the details frame
                        detailsFrame.add(panel);
                        detailsFrame.setVisible(true);
                }

                // Resize image icons
                private static ImageIcon resizeImageIcon(String filePath, int width, int height) {
                    ImageIcon icon = new ImageIcon(filePath);
                    Image img = icon.getImage();
                    Image resizedImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                    return new ImageIcon(resizedImage);
                }
}
